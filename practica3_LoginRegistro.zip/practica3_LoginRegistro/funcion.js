function registrarme() {
    const Username = document.getElementById('u1').value;

    document.getElementById('registro').innerHTML = "";
    document.getElementById('registro').innerHTML = "Registro con exito";
    document.getElementById('usuario').innerHTML = Username;
}

function login() {
    const Username = document.getElementById('u1').value;

    document.getElementById('registro').innerHTML = "";
    document.getElementById('registro').innerHTML = "Login con exito";
    document.getElementById('usuario').innerHTML = Username;
}