document.addEventListener("DOMContentLoaded", function() {
    const Search = document.getElementById("Search");
    const resultados = document.getElementById("res");

    Search.addEventListener("input", function() {
        const longitud = Search.value.trim();

        if(longitud.length > 0){
            resultados.style.display = "block";
        }
        else {
            resultados.style.display = "none";
        }
    });


});